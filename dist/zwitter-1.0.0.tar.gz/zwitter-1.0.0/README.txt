
CUI based Twitter Client made by Zweihander(sd852456@naver.com)
CUI에서 동작하는 트위터 클라이언트입니다
재미로 만든 것이니 너무 진지하게 사용하지 말아주세요 ㅠㅠ
버그 제보, 문의 등은 sd852456@naver.com이나 트위터 @panzerbruder로 보내주세요!

requires npyscreen
try sudo pip3 install npyscreen
동작에는 npyscreen이 필요합니다
sudo pip3 install npyscreen으로 설치하세요

