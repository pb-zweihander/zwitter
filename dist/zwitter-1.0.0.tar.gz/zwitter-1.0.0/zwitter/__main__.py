
from .zwitter import main

main()

